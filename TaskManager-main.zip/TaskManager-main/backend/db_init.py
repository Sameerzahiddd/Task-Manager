# db_init.py

from flask_sqlalchemy import SQLAlchemy

# Initialize the SQLAlchemy object for ORM
db = SQLAlchemy()
